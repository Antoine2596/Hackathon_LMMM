---
name: Other Issue
about: Not a bug, nor a feature request!
title: ''
labels: ''
assignees: ''

---

*Note*: We encourage questions about usage of SingularityCE to be asked using GitHub Discussions, our Google Group or Slack channels. GitHub issues are intended for bug reports, feature requests, and other development purposes.

See: https://sylabs.io/singularity#community for links.

**Type of issue**

E.g. test problem / technical debt / release tracking

**Description of issue**

Give a concise, but complete description of the issue here, with any information
that might be needed to investigate, or act on it.
